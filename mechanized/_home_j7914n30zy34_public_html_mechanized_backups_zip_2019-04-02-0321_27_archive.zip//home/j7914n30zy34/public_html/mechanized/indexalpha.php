<html>
<head> 
  <title>mechanized android</title> 
  <link rel="stylesheet" href="css/styles.css">
  <link rel="stylesheet" media="screen" href="https://fontlibrary.org/face/mononoki" type="text/css"/> 
  <link href="https://fonts.googleapis.com/css?family=Inconsolata|Montserrat" rel="stylesheet"> 
  <link rel="stylesheet" media="screen" href="https://fontlibrary.org/face/fantasque-sans-mono" type="text/css"/> 
</head>  
<body>

<div class="wrapper">
  <header>
  <center><p>mechanized v9.2.0</p></center>
  </header>
  <article>
    <h1>Welcome</h1>
    <p class="todo">TODO: style a subheader (ie byline, date etc)</p>
    <p class="todo">TODO: template for posts ---</p>
    <p>It is only by revolution that the native genius of the English people can be set free. Revolution does not mean red flags and street fighting, it means a fundamental shift of power. Whether it happens with or without bloodshed is largely an accident of time and place. Nor does it mean the dictatorship of a single class. The people in England who grasp what changes are needed and are capable of carrying them through are not confined to any one class, though it is true that very few people with over £2,000 a year are among them. What is wanted is a conscious open revolt by ordinary people against inefficiency, class privilege and the rule of the old. It is not primarily a question of change of government. British governments do, broadly speaking, represent the will of the people, and if we alter our structure from below we shall get the government we need. Ambassadors, generals, officials and colonial administrators who are senile or pro-Fascist are more dangerous than Cabinet ministers whose follies have to be committed in public. Right through our national life we have got to fight against privilege, against the notion that a half-witted public-schoolboy is better fitted for command than an intelligent mechanic. Although there are gifted and honest INDIVIDUALS among them, we have got to break the grip of the moneyed class as a whole. England has got to assume its real shape. The England that is only just beneath the surface, in the factories and the newspaper offices, in the aeroplanes and the submarines, has got to take charge of its own destiny.</p>
  </article> 
  <aside><!-- <ul><li>Sidebar</li></ul>--></aside>
  <footer><center>copyright is a scam. the current year is 2018. the current website is mechanized, hosted on yellowfog.xyz</center></footer>
</div>

</body>
</html>