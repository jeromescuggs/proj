<?php if(!defined('IN_GS')){ die('you cannot load this page directly.'); }
/****************************************************
*
* @File: 		template.php
* @Package:		GetSimple
* @Action:		PureGS - pure css framework for GetSimple CMS
*
*****************************************************/
?>

<!DOCTYPE html>

<html lang="en">

<head>
	<!-- Basic Page Needs
  ================================================== -->
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<meta name="description" content="A set of small, responsive CSS modules that you can use in every web project.">
	<title><?php get_page_clean_title(); ?> &mdash; <?php get_site_name(); ?></title>
	
	<!-- CSS
  ================================================== -->
	<link rel="stylesheet" href="http://yui.yahooapis.com/pure/0.3.0/pure-min.css">
	<link rel="stylesheet" href="<?php get_theme_url(); ?>/style.css">
	
	<!--[if lt IE 9]>
		<script src="http://html5shim.googlecode.com/svn/trunk/html5.js"></script>
	<![endif]-->

	<link rel="shortcut icon" href="<?php get_theme_url(); ?>/images/favicon.ico">
	
	<?php get_header(); ?>
</head>

<body id="<?php get_page_slug(); ?>" >

	<!-- Primary Page Layout
	================================================== -->

	

	<div id="container" class="pure-u-1">
		
		<nav class="pure-g-r">
			<div class="pure-u-1 pure-menu pure-menu-open pure-menu-horizontal">
				<ul><?php get_navigation(return_page_slug()); ?></ul>
			</div>
		</nav>
		
		<header class="pure-g-r">
			<div class="pure-u-1">
				<h1><a href="<?php get_site_url(); ?>"><?php get_site_name(); ?></a></h1>
				<h4 ><?php get_component('tagline');	?></h4>
			</div>
		</header>
	
		<div id="main" class="pure-g-r"	>
			<section class="pure-u-2-3">
				<h3><?php get_page_title(); ?></h3>
				<?php get_page_content(); ?>
			</section>
			<aside class="pure-u-1-3">
				<?php get_component('sidebar');	?>
			</aside>
		</div>
		
		<footer class="pure-g-r">
			<div class ="pure-u-1-2" >
				<p><?php get_site_name(); ?> &copy <?php echo date('Y'); ?></p>
			</div>
			<div class ="pure-u-1-2" >
				<p><?php get_site_credits(); ?></p>
			</div>
			<?php get_footer(); ?>
		</footer>
		
	</div><!-- close container -->


<!-- End Document
================================================== -->
</body>
</html>