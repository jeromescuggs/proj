<?php if(!defined('IN_GS')){ die('you cannot load this page directly.'); }?>
<!DOCTYPE html>
<html lang="en">
	<head>
		<title><?php get_site_name(); ?></title>
		<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
		<?php get_header(); ?>
		<link rel="stylesheet" href="<?php get_theme_url(); ?>/css/reset.css" type="text/css" media="all">
		<link rel="stylesheet" href="<?php get_theme_url(); ?>/css/layout.css" type="text/css" media="all">
		<link rel="stylesheet" href="<?php get_theme_url(); ?>/css/prettyPhoto.css" type="text/css" media="all">
		<link rel="stylesheet" href="<?php get_theme_url(); ?>/css/style.css" type="text/css" media="all">
		<script type="text/javascript" src="<?php get_theme_url(); ?>/js/jquery-1.6.js" ></script>
		<script type="text/javascript" src="<?php get_theme_url(); ?>/js/cufon-yui.js"></script>
		<script type="text/javascript" src="<?php get_theme_url(); ?>/js/cufon-replace.js"></script>
  		<script type="text/javascript" src="<?php get_theme_url(); ?>/js/Ubuntu_400.font.js"></script>
  		<script type="text/javascript" src="<?php get_theme_url(); ?>/js/Ubuntu_700.font.js"></script>
		<script type="text/javascript" src="<?php get_theme_url(); ?>/js/bgSlider.js" ></script>
		<script type="text/javascript" src="<?php get_theme_url(); ?>/js/script.js" ></script>
		<script type="text/javascript" src="<?php get_theme_url(); ?>/js/pages.js"></script>
		<script type="text/javascript" src="<?php get_theme_url(); ?>/js/jquery.easing.1.3.js"></script>
		<script type="text/javascript" src="<?php get_theme_url(); ?>/js/bg.js" ></script>
		<script type="text/javascript" src="<?php get_theme_url(); ?>/js/tabs.js"></script>
		<script type="text/javascript" src="<?php get_theme_url(); ?>/js/jquery.prettyPhoto.js"></script>
		<!--[if lt IE 9]>
			<script type="text/javascript" src="<?php get_theme_url(); ?>/js/html5.js"></script>
		<![endif]-->
		<!--[if lt IE 7]>
			<div style='clear:both;text-align:center;position:relative'>
				<a href="http://www.microsoft.com/windows/internet-explorer/default.aspx?ocid=ie6_countdown_bannercode"><img src="http://storage.ie6countdown.com/assets/100/images/banners/warning_bar_0000_us.jpg" border="0"  alt="" /></a>
			</div>
		<![endif]-->
	</head>
	<body id="page1">
		<div class="spinner"></div>
		<div id="bgSlider"></div>
		<div class="extra">
			<div class="main">
				<div class="box">
<!-- header -->
					<header>
						<h1><img id="logo" alt="<?php get_site_name(); ?>"></h1>
						<nav>
							<ul id="menu">
								<?php
global $pagesArray;
$pagesSorted = subval_sort($pagesArray,'menuOrder'); // or 'title', 'menu', 'url', ...
foreach ($pagesSorted as $page) if ($page['menuStatus']=='Y') {
    $pag = $page['meta'] == "" ? "#!/" . $page['url'] : $page['meta'];
								?>
								<li><a href="<?php echo $pag; ?>"><span></span><strong><?php getPageField($page['slug'],'menu'); ?></strong></a></li>
								<?php } ?>
							</ul>
						</nav>
					</header>
<!--content -->
					<article id="content">
						<ul>
							<?php foreach (menu_data() as $page) { ?>
							<li id="<?php echo $page['slug']; ?>">
								<div class="box1">
									<div class="inner">
										<a href="#" class="close" data-type="close"><span></span></a>
										<div class="wrapper">
											<h2><?php getPageField($page['slug'],'title'); ?></h2>
												<?php getPageContent($page['slug']); ?>
										</div>
									</div>
								</div>
							</li>
							<?php } ?>
						</ul>
					</article>
<!-- / content -->
				</div>
			</div>
			<div class="block"></div>
		</div>
		<div class="bg1">
			<div class="main">
<!-- footer -->
				<footer>
					<div class="bg_spinner"></div>
					<ul class="pagination">
						<li class="current"><a href="<?php get_theme_url(); ?>/images/bg_img1.jpg">1</a></li>
						<li><a href="<?php get_theme_url(); ?>/images/bg_img2.jpg">2</a></li>
						<li><a href="<?php get_theme_url(); ?>/images/bg_img3.jpg">3</a></li>
					</ul>
					<div class="col_2">
						Copyright &copy <a href="#"><?php get_site_name(); ?></a> &nbsp&nbsp&nbsp&nbsp Powered by <a href="http://get-simple.info/" target="_blank">GetSimple CMS</a> &nbsp&nbsp&nbsp&nbsp Designed by <a rel="nofollow" href="http://www.templatemonster.com/" target="_blank">TemplateMonster.com</a> | <a rel="nofollow" href="http://www.html5xcss3.com/" target="_blank">html5xcss3.com</a>
						<!-- {%FOOTER_LINK} -->
					</div>
				</footer>
<!-- / footer-->
			</div>
		</div>
		<script type="text/javascript"> Cufon.now(); </script>
		<script>
		$(window).load(function() {
			$('.spinner').fadeOut();
			$('body').css({overflow:'inherit'})
		})
		</script>
	</body>
</html>