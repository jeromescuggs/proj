<?php if(!defined('IN_GS')){ die('you cannot load this page directly.'); }
/****************************************************
*
* @File:      template.php
* @Package:   GetSimple
* @Action:    mechanized v9 gs layout
*
*****************************************************/
?>
<!DOCTYPE html>
<!--
/*

+-------------------------------------------+
+ mechanized v9.0                           +
+ component: template/index.html [php]      +
+ author: andrew snow [jeromescuggs]        +
+-------------------------------------------+
+ (with, of course, liberal applications of +
+    open source code and/or getsimple      +
+              php functions)               +    
+-------------------------------------------+

-->
<html>
<?php include("assets/header.inc.php"); ?>
<body>

<div id='topwrap'> 
  <div id='twcont'> 
       yf
  </div> 
</div> 
<div id='top'> 
  <div id='top-left-s'>
  spacer 
  </div> 
  <div id="top-left"> 
      <h1>mechanized</h1> 
      <p>catatonic leisure</p>
  </div>
  <div id='top-right'> 
      <p>a yellowfog design</p>
  </div> 
  <div id='top-right-s'> 
  spacer 
  </div> 
</div> 
<div id='main'> 
  <div id='main-left'>
  spacer 
  </div> 
  <div id='content'> 
      <p>MAIN CONTENT</p> 
  </div> 
  <div id='main-right'> 
  spacer
  </div> 
</div> 
<div id='bottom'> 
  <div id='btm-left-s'> 
  </div> 
  <div id='btm-left'> 
      <p>bottom leftmenu</p> 
  </div> 
  <div id='btm-right'> 
      <p>bottom rightmenu</p> 
  </div> 
  <div id='btm-right-s'> 
  </div> 
</div> 
<div id='btmwrap'> 
  <div id='bwcont'> 
      <p>if all goes according to plan, this will span the entirety of the bottom part of the page - basically mirroring the topmost element with the embedded image</p> 
  </div> 
</div> 

</body>
</html></div> 
</div> 

</body>
</html>