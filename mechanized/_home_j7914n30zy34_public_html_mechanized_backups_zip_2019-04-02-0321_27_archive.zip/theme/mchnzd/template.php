<?php if(!defined('IN_GS')){ die('you cannot load this page directly.'); }
/****************************************************
*
* @File:      template.php
* @Package:   GetSimple
* @Action:    mechanized v9 gs layout
*
*****************************************************/
?>
<!DOCTYPE html> 
<html>
<head> 
<title>mechanized android</title> 
  <link rel="stylesheet" href="https://fadestate.com/mechanized/theme/mchnzd/css/styles.css">
  <link rel="stylesheet" media="screen" href="https://fontlibrary.org/face/mononoki" type="text/css"/> 
  <link href="https://fonts.googleapis.com/css?family=Inconsolata|Montserrat" rel="stylesheet"> 
  <link rel="stylesheet" media="screen" href="https://fontlibrary.org/face/fantasque-sans-mono" type="text/css"/> 
<?php get_header(); ?>
</head>  
<body>

<div class="wrapper">
  <header>
  <center>
    <h2>mechanized x</h2><br />
    catatonic leisure at one thousand miles per hour<!--<hr />--><br />
	  <nav>
		  <ul><?php get_i18n_navigation(return_page_slug(), 0, 0); ?></ul>
	  </nav>
</center>
	  <!-- i know, i know - who uses the center tag anymore, right? well guess what, i do. it's like when you buy handmade shit that has imperfections in it - lets you know a human made it. :P -->
    <br>
  </header>
  <article>
    <div>
     <?php get_page_content(); ?>
    </div>
     </article> 
  <aside>
	  <?php /* get_navigation(return_page_slug()); */ ?>
	  <!-- <ul><li>Sidebar</li></ul>--></aside>
  <footer><center>copyright is a scam. the current year is 2018. the current website is mechanized, hosted on fadestate</center></footer>
</div>

</body>
</html>
