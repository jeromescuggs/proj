<?php if(!defined('IN_GS')){ die('you cannot load this page directly.'); }
/****************************************************
*
* @File: 		template.php
* @Package:		Material
* @Createt:		Matthias Knoll aka Prazaar
*
*****************************************************/
?>

<!DOCTYPE html>
<head>
<meta charset="utf-8"/>

<title><?php get_page_clean_title(); ?> < <?php get_site_name(); ?></title>
<?php get_header(); ?>

<link rel="stylesheet" href="//maxcdn.bootstrapcdn.com/bootstrap/3.3.4/css/bootstrap.min.css">
<link rel="stylesheet" href="//maxcdn.bootstrapcdn.com/font-awesome/4.3.0/css/font-awesome.min.css">
<link rel="stylesheet" type="text/css" href="<?php get_theme_url(); ?>/style.css">

<script type="text/javascript" src="//ajax.googleapis.com/ajax/libs/jquery/2.1.3/jquery.min.js"></script>
<script src="//maxcdn.bootstrapcdn.com/bootstrap/3.3.4/js/bootstrap.min.js"></script>

<link rel="stylesheet" type="text/css"  href="//fonts.googleapis.com/css?family=Cutive+Mono">

<meta name="viewport" content="width=device-width, initial-scale=1.0">
<meta name="theme-color" content="#4D698E">
	
</head>
<body id="<?php get_page_slug(); ?>" >

        <div id="page-navbar" class="navbar navbar-default navbar-fixed-top">
            <div class="container">

                
                <p class="navbar-text"><?php get_site_name(); ?></p>

                <div class="navbar-right">

                    <ul id="page-top-nav" class="nav navbar-nav">
                        <li>
                        <?php get_navigation(return_page_slug()); ?>
                        </li>
                    </ul>
                    
                </div>

            </div>
        </div>

        <div id="page-content" class="container">

		<div class="panel panel-default">
  			<div class="panel-heading"><?php get_page_title(); ?></div>
  				<div class="panel-body">
    				<?php get_page_content(); ?>
  				</div>
			</div>

        	</div>
        </div>
        
<div class="footer">
<br />
<ul class="breadcrumb">
  <li class="active">&copy; 2016 by <?php get_site_name(); ?></li>
</ul>
</div>
</body>
</html>

